<?php ob_start(); the_content(); $content = ob_get_clean();
global $pageLostPassword, $pageLogin, $pageRegister;
if ($pageLostPassword) {
	$template = $pathToFormsTemplates . 'lostpassword.php';
	ob_start();
	if (file_exists($template)) {
		include_once $template;
	}
	$formAndLinks = ob_get_clean(); echo preg_replace('/<form[\s\S]*?\/ul>/', $formAndLinks, $content) ?>
<?php }
else if ($pageRegister) {
	$template = $pathToFormsTemplates . 'register.php';
	ob_start();
	if (file_exists($template)) {
		include_once $template;
	}
	$formAndLinks = ob_get_clean(); echo preg_replace('/<form[\s\S]*?\/ul>/', $formAndLinks, $content) ?>
<?php } else {
	$template = $pathToFormsTemplates . 'login.php';
	ob_start();
	if (file_exists($template)) {
		include_once $template;
	}
	$formAndLinks = ob_get_clean(); echo preg_replace('/<form[\s\S]*?\/ul>/', $formAndLinks, $content);
} ?>