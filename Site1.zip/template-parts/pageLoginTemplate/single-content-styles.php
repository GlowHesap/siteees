<!-- post styles -->

<style>.u-section-1 .u-sheet-1 {
  min-height: 541px;
}
.u-section-1 .u-form-1 {
  width: 570px;
  margin: 48px auto 0 0;
}
.u-section-1 .u-btn-2 {
  border-style: none none solid;
  margin: 30px 0 0;
  padding: 0;
}
.u-section-1 .u-btn-3 {
  border-style: none none solid;
  margin: 30px 0 0;
  padding: 0;
}
.u-section-1 .u-btn-4 {
  border-style: none none solid;
  margin: 30px 0 0;
  padding: 0;
}
@media (max-width: 1199px) {
  .u-section-1 .u-form-1 {
    width: 470px;
  }
}
@media (max-width: 575px) {
  .u-section-1 .u-form-1 {
    width: 340px;
  }
}
</style>
