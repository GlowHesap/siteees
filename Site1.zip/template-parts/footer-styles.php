<!-- footer styles -->

<style>.u-footer .u-sheet-1 {
  min-height: 120px;
}
.u-footer .u-social-icons-1 {
  height: 80px;
  min-height: 16px;
  width: 622px;
  min-width: 364px;
  white-space: nowrap;
  margin: 14px auto 26px;
}
.u-footer .u-icon-1 {
  height: 100%;
  color: rgb(197, 54, 164) !important;
}
.u-footer .u-icon-2 {
  height: 100%;
  color: rgb(210, 34, 21) !important;
}
.u-footer .u-icon-3 {
  height: 100%;
  color: rgb(3, 155, 229) !important;
}
.u-footer .u-icon-4 {
  height: 100%;
  color: rgb(219, 83, 75) !important;
}
@media (max-width: 1199px) {
  .u-footer .u-sheet-1 {
    min-height: 99px;
  }
  .u-footer .u-social-icons-1 {
    width: 622px;
  }
}
@media (max-width: 991px) {
  .u-footer .u-sheet-1 {
    min-height: 76px;
  }
}
@media (max-width: 767px) {
  .u-footer .u-sheet-1 {
    min-height: 57px;
  }
}
@media (max-width: 575px) {
  .u-footer .u-sheet-1 {
    min-height: 36px;
  }
}</style>
