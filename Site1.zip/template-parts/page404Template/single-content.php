<?php $skip_min_height = false; ?><section class="u-align-center u-clearfix u-section-1" id="sec-526f">
  <div class="u-clearfix u-sheet u-valign-middle u-sheet-1">
    <div class="u-align-left u-text u-text-default u-text-not-found-message u-text-1"><?php theme_404_content(); ?></div>
  </div>
</section><?php if ($skip_min_height) { echo "<style> .u-section-1, .u-section-1 .u-sheet {min-height: auto;}</style>"; } ?>
